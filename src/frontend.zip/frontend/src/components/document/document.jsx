import styles from "./document.module.css"

import Input from "../input/input"

export default function Document () {
    
}