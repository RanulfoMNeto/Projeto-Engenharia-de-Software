export default function Teste ({children}) {
  return (
    <>
      <div>
        {children}
      </div>
    </>
  )
}